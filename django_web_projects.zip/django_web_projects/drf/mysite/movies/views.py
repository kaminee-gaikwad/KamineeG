from django.shortcuts import render
from rest_framework import viewsets
from.serializers import MovieSerializer
from.models import Moviesdata

# Create your views here.
class MovieViewsSet(viewsets.ModelViewSet):
    queryset=Moviesdata.objects.all()
    serializer_class=MovieSerializer

class ActionViewSet(viewsets.ModelViewSet):
    queryset=Moviesdata.objects.filter(typ='action')
    serializer_class=MovieSerializer

class ComedyViewSet(viewsets.ModelViewSet):
    queryset=Moviesdata.objects.filter(typ='comedy')
    serializer_class=MovieSerializer


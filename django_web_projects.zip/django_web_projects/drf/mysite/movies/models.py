from django.db import models

# Create your models here.
class Moviesdata(models.Model):
     def __str__(self):
          return self.name

     name=models.CharField(max_length=200)
     duration=models.FloatField()
     rating=models.FloatField()
     #ratin1=models.URLField()
     typ=models.CharField(max_length=200,default='action')
     


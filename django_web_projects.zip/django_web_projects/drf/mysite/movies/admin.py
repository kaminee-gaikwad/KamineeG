from django.contrib import admin
from.models import Moviesdata
# Register your models here.

admin.site.register(Moviesdata)
#kamg kams
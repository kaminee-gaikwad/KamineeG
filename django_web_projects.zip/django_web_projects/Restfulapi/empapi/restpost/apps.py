from django.apps import AppConfig


class RestpostConfig(AppConfig):
    name = 'restpost'
